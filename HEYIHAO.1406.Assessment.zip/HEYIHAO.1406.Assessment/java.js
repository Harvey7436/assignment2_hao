function displayResult()  { 
    var name = document.getElementById("yourname").value;
    var e = document.getElementById("youremail").value;
    var b = document.getElementById("myDate").value;
	var a = document.getElementById("address").value;
	var r = document.getElementById("remarks").value;
/*     var p = document.getElementById("product").value; */
    if(name== "") {
        alert("Please enter your name, it should not be blank");
        return false;
    }
    if(e == "") {
        alert("Please enter you email.");
        return false;
    }
	if(b==""){
		alert("Please enter your birthday.");
		return false;
	}
	if(a==""){
		alert(" Please enter your address");
		return false;
		}
	if(r==""){
		alert(" Please enter your remarks");
		return false;
		}
		
    var message = "Thank you for signing up for the Petite Treats Weekly newsletter" +
     "\nWe have added the following information to our files regarding your interests:" +
      "\nName: " + name +
      "\nEmail: " + e +
/*       "\nProduct interests: " + p +  */
      "\nBirthday: " + b ;

    alert(message);

    return true;
}